package com.sociogen.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
