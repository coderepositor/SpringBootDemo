package com.sociogen.crudh2db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankAppH2Application {

	public static void main(String[] args) {
		SpringApplication.run(BankAppH2Application.class, args);
	}

}
