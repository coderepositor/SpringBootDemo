package com.sociogen.crudh2db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankAppH2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
